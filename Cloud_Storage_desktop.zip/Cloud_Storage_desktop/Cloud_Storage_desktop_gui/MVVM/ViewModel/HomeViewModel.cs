﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cloud_Storage_desktop.Core;
using Cloud_Storage_desktop.MVVM.View;

namespace Cloud_Storage_desktop.MVVM.ViewModel
{
    class HomeViewModel
    {
        
    }
}
